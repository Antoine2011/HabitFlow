/* ============================================================
   HabitFlow — app.js
   ============================================================ */

// ---- STRIPE LINK ----
const STRIPE_URL = 'https://buy.stripe.com/test_fZu7sN2TF15zgiO4LmaMU00';

function openStripe() {
  window.open(STRIPE_URL, '_blank');
}

function openApp() {
  document.getElementById('app-modal').classList.add('open');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

function openContact() {
  window.location.href = 'mailto:hello@habitflow.app?subject=Partenariat HabitFlow';
}

// ---- MOBILE MENU ----
function toggleMenu() {
  const menu = document.getElementById('mobile-menu');
  menu.classList.toggle('open');
}

// ---- MODAL TABS ----
function switchTab(tab) {
  document.querySelectorAll('.mtab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-login').style.display = tab === 'login' ? 'flex' : 'none';
  document.getElementById('tab-register').style.display = tab === 'register' ? 'flex' : 'none';
  event.target.classList.add('active');
}

// ---- BILLING TOGGLE ----
function setBilling(type) {
  document.getElementById('tog-monthly').classList.toggle('active', type === 'monthly');
  document.getElementById('tog-yearly').classList.toggle('active', type === 'yearly');
  const priceEl = document.getElementById('price-display');
  const periodEl = document.getElementById('period-display');
  const descEl = document.getElementById('plan-desc-text');
  if (type === 'yearly') {
    priceEl.textContent = '2,99€';
    periodEl.textContent = '/ mois';
    descEl.textContent = 'Facturé 35,88€/an. Économisez 24€ par rapport au mensuel.';
  } else {
    priceEl.textContent = '4,99€';
    periodEl.textContent = '/ mois';
    descEl.textContent = 'Facturé mensuellement. Annulable à tout moment.';
  }
}

// ---- HEATMAP MINI ----
function buildHeatmap() {
  const el = document.getElementById('hmap-mini');
  if (!el) return;
  const levels = [0, 0, 1, 1, 2, 2, 3, 4];
  let html = '';
  for (let i = 0; i < 91; i++) {
    const l = levels[Math.floor(Math.random() * levels.length)];
    html += `<div class="hmap-cell hmap-${l}"></div>`;
  }
  el.innerHTML = html;
}

// ---- NAV SCROLL ----
function handleNavScroll() {
  const nav = document.getElementById('nav');
  if (window.scrollY > 50) {
    nav.classList.add('scrolled');
  } else {
    nav.classList.remove('scrolled');
  }
}

// ---- SCROLL REVEAL ----
function initReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

// ---- COUNTER ANIMATION ----
function animateCounter(el, target, suffix = '') {
  const duration = 2000;
  const start = Date.now();
  const isFloat = target % 1 !== 0;

  const tick = () => {
    const elapsed = Date.now() - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = target * eased;
    el.textContent = isFloat
      ? current.toFixed(1).replace('.', ',') + suffix
      : Math.floor(current).toLocaleString('fr-FR') + suffix;
    if (progress < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function initCounters() {
  const counters = document.querySelectorAll('.stat-num');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.dataset.animated) {
        entry.target.dataset.animated = true;
        const text = entry.target.textContent;
        const suffix = entry.target.querySelector('span')?.textContent || '';
        // Parse number
        const raw = text.replace(/[^0-9,\.]/g, '').replace(',', '.');
        const num = parseFloat(raw);
        if (!isNaN(num)) {
          const span = entry.target.querySelector('span');
          animateCounter(entry.target, num, '');
          // Re-append suffix span after tick
          setTimeout(() => {
            if (span && !entry.target.querySelector('span')) {
              entry.target.appendChild(span);
            }
          }, 2100);
        }
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(c => observer.observe(c));
}

// ---- PHONE MOCKUP ANIMATION ----
function animatePhone() {
  const habits = document.querySelectorAll('.ph-habit');
  let idx = 0;
  setInterval(() => {
    if (habits[idx]) {
      habits[idx].classList.toggle('done');
    }
    idx = (idx + 1) % habits.length;
  }, 2000);
}

// ---- CLOSE MODAL ON ESC ----
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
  }
});

// ---- SMOOTH SCROLL FOR NAV LINKS ----
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', (e) => {
    const href = a.getAttribute('href');
    if (href === '#') return;
    const target = document.querySelector(href);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  buildHeatmap();
  initReveal();
  initCounters();
  animatePhone();
  window.addEventListener('scroll', handleNavScroll, { passive: true });

  // Trigger initial reveal for above-fold elements
  setTimeout(() => {
    document.querySelectorAll('.hero .reveal').forEach(el => el.classList.add('visible'));
  }, 100);
});
